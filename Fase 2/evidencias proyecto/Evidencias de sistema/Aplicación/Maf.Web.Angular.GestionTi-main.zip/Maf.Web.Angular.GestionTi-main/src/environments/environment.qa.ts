// Ambiente QA. Se usa con: ng build --configuration qa (lo hace GitHub Actions).
// Estos valores quedan dentro del JavaScript que descarga el navegador: no poner secretos aquí.
export const environment = {
  // Mismo dominio que el front: CloudFront envía /api/* al backend (ALB interno → ECS). No requiere CORS.
  apiUrl: 'https://gestionti-qa.mafti.cl/api',

  // Microsoft Entra ID. redirectUri debe estar registrada tal cual en la app registration (tipo SPA).
  entra: {
    tenantId: '04e057b1-ca2d-4bca-abce-785313a23d18',
    clientId: 'e985ba87-07ee-4f0c-9712-e7aa9bf2ad78',
    redirectUri: 'https://gestionti-qa.mafti.cl',
    apiScope: 'api://e985ba87-07ee-4f0c-9712-e7aa9bf2ad78/access_as_user'
  },

  loginDesarrollo: false
};
