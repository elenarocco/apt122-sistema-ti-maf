import { Component, OnInit, ChangeDetectorRef, computed,inject } from '@angular/core';
import { RouterLink } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { SesionService } from '../../../core/sesion';
import { PERMISOS_CREAR_SOLICITUD } from '../../../core/permisos';
import { environment } from '../../../../environments/environment';

interface Resumen {
  alcance: string; // "Empresa completa" o el área del usuario (Jefatura)
  dotacionActual: number;
  ingresosDelMes: number;
  bajasDelMes: number;
  solicitudesPendientes: number;
  solicitudesUrgentes: number;
  porTipo: { tipo: string; cantidad: number }[];
  movimientos: { mes: string; ingresos: number; bajas: number }[];
}

interface FilaSolicitud {
  nombre: string; iniciales: string; area: string; tipo: string;
  fecha: string; estadoTexto: string; estadoClase: string;
}

@Component({
  selector: 'app-panel',
  imports: [RouterLink],
  templateUrl: './panel.html',
  styleUrl: './panel.scss'
})
export class Panel implements OnInit {
  private api = environment.apiUrl;

  private sesion = inject(SesionService);

  puedeCrearSolicitud = computed(() => {
    // Según los permisos que entrega el backend (RRHH crea Bloqueos, Jefatura Ingresos, etc.).
    return this.sesion.tieneAlguno(PERMISOS_CREAR_SOLICITUD);
  });
  resumen: Resumen | null = null;
  subtitulo = '';
  tiposResumen: { etiqueta: string; cantidad: number; porcentaje: number }[] = [];
  meses: { etiqueta: string; ingresos: number; bajas: number; hIngresos: number; hBajas: number }[] = [];
  recientes: FilaSolicitud[] = [];

  private etiquetasTipo: Record<string, string> = {
    'Ingreso': 'Solicitudes de ingreso',
    'Modificación': 'Modificaciones de acceso',
    'Bloqueo': 'Bloqueos de cuenta',
    'VPN': 'Solicitudes VPN'
  };

  constructor(
    private http: HttpClient,
    private cdr: ChangeDetectorRef
    
  ) { }

  ngOnInit(): void {
    const hoy = new Date();
    const mes = hoy.toLocaleDateString('es-CL', { month: 'long' });
    const periodo = `${mes.charAt(0).toUpperCase() + mes.slice(1)} ${hoy.getFullYear()}`;
    this.subtitulo = periodo;

    this.http.get<Resumen>(`${this.api}/Dashboard/resumen`).subscribe(r => {
      this.resumen = r;
      this.subtitulo = `${periodo} · ${r.alcance}`;
      const maxTipo = Math.max(1, ...r.porTipo.map(t => t.cantidad));
      this.tiposResumen = Object.keys(this.etiquetasTipo).map(clave => {
        const cantidad = r.porTipo.find(t => t.tipo === clave)?.cantidad ?? 0;
        return { etiqueta: this.etiquetasTipo[clave], cantidad, porcentaje: cantidad / maxTipo * 100 };
      });
      const maxMov = Math.max(1, ...r.movimientos.flatMap(m => [m.ingresos, m.bajas]));
      this.meses = r.movimientos.map(m => {
        const corto = new Date(m.mes + 'T00:00:00').toLocaleDateString('es-CL', { month: 'short' }).replace('.', '');
        return {
          etiqueta: corto.charAt(0).toUpperCase() + corto.slice(1),
          ingresos: m.ingresos, bajas: m.bajas,
          hIngresos: m.ingresos / maxMov * 100,
          hBajas: m.bajas / maxMov * 100
        };
      });
      this.cdr.detectChanges();
    });

    this.http.get<{ items: any[] }>(`${this.api}/solicitudes?pagina=1&tamano=5`).subscribe(r => {
      this.recientes = r.items.map(s => {
        const [estadoTexto, estadoClase] = this.estado(s);
        const nombre: string = s.trabajadorNombre ?? 'Proveedor por definir';
        return {
          nombre,
          iniciales: nombre.split(' ').filter(Boolean).slice(0, 2).map((p: string) => p[0]).join('').toUpperCase(),
          area: s.areaNombre ?? '—',
          tipo: s.tipo,
          fecha: new Date(s.fechaCreacion).toLocaleDateString('es-CL', { day: 'numeric', month: 'short' }).replace('.', ''),
          estadoTexto, estadoClase
        };
      });
      this.cdr.detectChanges();
    });
  }

  private estado(s: any): [string, string] {
    if (s.estado === 'Pendiente') {
      return s.vencida ? ['Urgente', 'urgente'] : ['Pendiente', 'pendiente'];
    }
    if (s.estado === 'EnProceso' || s.estado === 'En proceso') return ['En proceso', 'proceso'];
    if (s.estado === 'Completada') return ['Completada', 'completada'];
    return ['Rechazada', 'rechazada'];
  }
}