using Microsoft.EntityFrameworkCore;
using Npgsql;

namespace MafTi.Api.Common;

// Conexión a PostgreSQL. La cadena se toma, en este orden, de:
// 1) ConnectionStrings:Default (user-secrets en desarrollo, o variable ConnectionStrings__Default).
// 2) DB_HOST, DB_PORT, DB_NAME, DB_USERNAME y DB_PASSWORD: las inyecta ECS (Terraform, desde Secrets Manager).
//    Se arma con SSL obligatorio, que RDS exige, y un pool máximo de 20 conexiones por tarea.
public static class ConexionBaseDatos
{
    public static string? Resolver(IConfiguration config)
    {
        var conexion = config.GetConnectionString("Default");
        if (!string.IsNullOrWhiteSpace(conexion)) return conexion;

        var host = config["DB_HOST"];
        if (string.IsNullOrWhiteSpace(host)) return null;

        var faltantes = new[] { "DB_NAME", "DB_USERNAME", "DB_PASSWORD" }
            .Where(k => string.IsNullOrWhiteSpace(config[k])).ToArray();
        if (faltantes.Length > 0)
            throw new InvalidOperationException(
                $"Está DB_HOST pero faltan las variables {string.Join(", ", faltantes)}. Ver CONFIGURACION.md.");

        var puertoTexto = config["DB_PORT"];
        var puerto = 5432;
        if (!string.IsNullOrWhiteSpace(puertoTexto) && !int.TryParse(puertoTexto, out puerto))
            throw new InvalidOperationException($"DB_PORT no es un número válido: '{puertoTexto}'.");

        // El builder escapa los valores: una contraseña con ';' o '=' no rompe la cadena.
        return new NpgsqlConnectionStringBuilder
        {
            Host = host,
            Port = puerto,
            Database = config["DB_NAME"],
            Username = config["DB_USERNAME"],
            Password = config["DB_PASSWORD"],
            SslMode = SslMode.Require,
            MaxPoolSize = 20
        }.ConnectionString;
    }

    // Al arrancar, la base puede no estar lista todavía (en QA, RDS se enciende por horario).
    // Reintenta cada 10 s durante 2 minutos; si sigue sin responder, la API no arranca y ECS levanta otra tarea.
    public static async Task EsperarAsync(DbContext db, ILogger logger)
    {
        const int intentos = 12;
        for (var intento = 1; ; intento++)
        {
            try
            {
                await db.Database.OpenConnectionAsync();
                await db.Database.CloseConnectionAsync();
                return;
            }
            catch (Exception ex) when (intento < intentos)
            {
                logger.LogWarning("La base de datos no responde (intento {Intento} de {Total}): {Motivo}. Reintento en 10 s.",
                    intento, intentos, ex.Message);
                await Task.Delay(TimeSpan.FromSeconds(10));
            }
        }
    }
}
