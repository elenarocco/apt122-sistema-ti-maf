using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.Identity.Web;
using MafTi.Api.Common;
using MafTi.Api.Seguridad;
using MafTi.Infrastructure;

var builder = WebApplication.CreateBuilder(args);
var esDesarrollo = builder.Environment.IsDevelopment();

// Los secretos no van en appsettings: en desarrollo vienen de user-secrets y en el servidor de
// variables de entorno (ConnectionStrings__Default, o DB_HOST/DB_USERNAME/... en ECS). Ver CONFIGURACION.md.
var conexion = ConexionBaseDatos.Resolver(builder.Configuration);
if (string.IsNullOrWhiteSpace(conexion))
    throw new InvalidOperationException(
        "Falta la conexión a la base de datos. En desarrollo: dotnet user-secrets set \"ConnectionStrings:Default\" \"...\"; " +
        "en el servidor: ConnectionStrings__Default o las variables DB_HOST, DB_NAME, DB_USERNAME y DB_PASSWORD. Ver CONFIGURACION.md.");

builder.Services.AddDbContext<AppDbContext>(options => options.UseNpgsql(conexion));

// Autenticación: token de Microsoft Entra ID (sección AzureAd). En Development se acepta además
// el token del login de desarrollo; fuera de Development ese esquema y su clave no se registran.
const string EsquemaSesion = "Sesion";
var auth = builder.Services
    .AddAuthentication(o =>
    {
        o.DefaultScheme = EsquemaSesion;
        o.DefaultChallengeScheme = EsquemaSesion;
    })
    .AddPolicyScheme(EsquemaSesion, EsquemaSesion, o =>
        o.ForwardDefaultSelector = context =>
            esDesarrollo && AuthDesarrollo.EsTokenDeDesarrollo(context)
                ? AuthDesarrollo.Esquema
                : JwtBearerDefaults.AuthenticationScheme);
foreach (var clave in new[] { "TenantId", "ClientId", "Audience" })
    if (string.IsNullOrWhiteSpace(builder.Configuration[$"AzureAd:{clave}"]))
        throw new InvalidOperationException($"Falta AzureAd:{clave} (datos de la app en Entra ID, van en appsettings.json). Ver backend/CONFIGURACION.md.");
auth.AddMicrosoftIdentityWebApi(builder.Configuration.GetSection("AzureAd"));
if (esDesarrollo) auth.AgregarEsquema(builder.Configuration);

builder.Services.AddScoped<UsuarioActual>();
builder.Services.AddScoped<ServicioSla>();

builder.Services.AddOpenApi();
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.AgregarSeguridadHttp();

var app = builder.Build();
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
    var logger = scope.ServiceProvider.GetRequiredService<ILogger<Program>>();
    await ConexionBaseDatos.EsperarAsync(db, logger);

    // En ECS la base solo es alcanzable desde la VPC: las migraciones las aplica la propia API al arrancar
    // cuando BaseDatos__AplicarMigraciones=true. En desarrollo se siguen aplicando con dotnet ef.
    if (app.Configuration.GetValue<bool>("BaseDatos:AplicarMigraciones"))
    {
        logger.LogInformation("Aplicando migraciones pendientes de la base de datos.");
        await db.Database.MigrateAsync();
    }

    await db.Trabajadores.AsNoTracking().Take(1).ToListAsync();

    // Base nueva: crea el primer usuario "Gestión General" si se configuró BaseDatos:AdministradorInicial.
    // Va después de las migraciones (necesita el rol y los catálogos). Un error aquí no impide arrancar.
    try
    {
        await AdministradorInicial.CrearSiFaltaAsync(db, app.Configuration, logger);
    }
    catch (Exception ex)
    {
        logger.LogError(ex, "Administrador inicial: no se pudo crear. La API sigue arrancando.");
    }

    if (esDesarrollo)
        await AuthDesarrollo.SembrarUsuariosAsync(db, logger);
}
app.UsarSeguridadHttp();

// Cualquier error no controlado se registra en el servidor y al cliente solo le llega un JSON genérico:
// nunca un stack trace ni detalles internos, sin importar el entorno.
app.UseExceptionHandler(builder => builder.Run(async context =>
{
    var ex = context.Features.Get<Microsoft.AspNetCore.Diagnostics.IExceptionHandlerPathFeature>()?.Error;
    app.Logger.LogError(ex, "Error no controlado en {Ruta}", context.Request.Path);
    context.Response.StatusCode = StatusCodes.Status500InternalServerError;
    context.Response.ContentType = "application/json";
    await context.Response.WriteAsJsonAsync(new { error = "Ocurrió un error inesperado. Inténtalo de nuevo o avisa a TI." });
}));

if (app.Environment.IsDevelopment())
{
    app.MapOpenApi();
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseAuthentication();
app.UseMiddleware<UsuarioActualMiddleware>();
app.MapControllers();

// Health check del balanceador: responde solo si la API arrancó (al iniciar ya se probó la conexión a la BD).
// Está fuera de /api, así que no exige sesión, y queda exento del filtro de dominios (ver SeguridadHttp).
app.MapGet(SeguridadHttp.RutaSalud, () => Results.Ok(new { estado = "ok" }));

if (esDesarrollo) AuthDesarrollo.MapearEndpoints(app);

app.Run();
