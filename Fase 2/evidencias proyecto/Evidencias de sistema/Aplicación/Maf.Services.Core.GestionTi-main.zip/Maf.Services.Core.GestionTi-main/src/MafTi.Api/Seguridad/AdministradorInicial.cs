using MafTi.Application;
using MafTi.Domain;
using MafTi.Infrastructure;
using Microsoft.EntityFrameworkCore;

namespace MafTi.Api.Seguridad;

// Primer administrador de una base nueva. Se configura con variables de entorno (en ECS, Terraform):
//   BaseDatos__AdministradorInicial__Correo    correo de Entra ID (obligatorio para activar)
//   BaseDatos__AdministradorInicial__Rut       RUT con dígito verificador
//   BaseDatos__AdministradorInicial__Nombre    primer nombre
//   BaseDatos__AdministradorInicial__Apellido  primer apellido
// Solo actúa si todavía no hay ningún usuario activo con el rol "Gestión General": después de crear el
// primero, la variable deja de tener efecto y los demás usuarios se administran desde la aplicación.
// Los roles y catálogos deben existir (los carga la migración DatosIniciales). Si falta algo, lo deja en el
// log y la API arranca igual.
public static class AdministradorInicial
{
    public const string RolAdministrador = "Gestión General";
    private const string Seccion = "BaseDatos:AdministradorInicial";

    public static async Task CrearSiFaltaAsync(AppDbContext db, IConfiguration config, ILogger logger)
    {
        var datos = config.GetSection(Seccion);
        var correo = datos["Correo"]?.Trim().ToLowerInvariant();
        if (string.IsNullOrWhiteSpace(correo)) return;

        var rol = await db.Roles.FirstOrDefaultAsync(r => r.Nombre == RolAdministrador);
        if (rol == null)
        {
            logger.LogWarning("Administrador inicial: no existe el rol {Rol}. Falta cargar los datos iniciales.", RolAdministrador);
            return;
        }

        if (await db.UsuariosSistema.AnyAsync(u => u.RolId == rol.Id && u.Activo && u.Trabajador!.Activo))
            return;

        var trabajador = await db.Trabajadores.FirstOrDefaultAsync(t => t.Correo.ToLower() == correo);
        if (trabajador == null)
        {
            trabajador = await NuevoTrabajadorAsync(db, datos, correo, logger);
            if (trabajador == null) return;
            db.Trabajadores.Add(trabajador);
            await db.SaveChangesAsync();
        }
        else trabajador.Activo = true;

        // Un solo UsuarioSistema por trabajador (índice único): si ya tiene uno, se le asigna el rol.
        var usuario = await db.UsuariosSistema.FirstOrDefaultAsync(u => u.TrabajadorId == trabajador.Id);
        if (usuario == null)
        {
            usuario = new UsuarioSistema { TrabajadorId = trabajador.Id, AreaId = null };
            db.UsuariosSistema.Add(usuario);
        }
        usuario.RolId = rol.Id;
        usuario.Activo = true;
        await db.SaveChangesAsync();

        // Sin el correo en el log: es un dato personal.
        logger.LogInformation("Administrador inicial: quedó un usuario activo con rol {Rol} (UsuarioSistema {Id}).",
            RolAdministrador, usuario.Id);
    }

    private static async Task<Trabajador?> NuevoTrabajadorAsync(AppDbContext db, IConfigurationSection datos, string correo, ILogger logger)
    {
        var rut = datos["Rut"]?.Trim() ?? "";
        var nombre = datos["Nombre"]?.Trim() ?? "";
        var apellido = datos["Apellido"]?.Trim() ?? "";
        if (nombre.Length == 0 || apellido.Length == 0)
        {
            logger.LogWarning("Administrador inicial: faltan {Seccion}:Nombre o {Seccion}:Apellido.", Seccion, Seccion);
            return null;
        }
        var errorRut = TrabajadorValidator.ValidarFormatoRut(rut);
        if (errorRut != null)
        {
            logger.LogWarning("Administrador inicial: RUT no válido ({Error}).", errorRut);
            return null;
        }

        // Datos laborales provisionales (los primeros activos de cada catálogo). Se corrigen después en la ficha.
        var area = await db.Catalogos.Where(c => c.Tipo == "Area" && c.PadreId != null && c.Activo).OrderBy(c => c.Id).FirstOrDefaultAsync();
        var cargoId = await db.Catalogos.Where(c => c.Tipo == "Cargo" && c.Activo).OrderBy(c => c.Id).Select(c => (int?)c.Id).FirstOrDefaultAsync();
        var lugarId = await db.Catalogos.Where(c => c.Tipo == "LugarTrabajo" && c.Activo).OrderBy(c => c.Id).Select(c => (int?)c.Id).FirstOrDefaultAsync();
        if (area == null || cargoId == null || lugarId == null)
        {
            logger.LogWarning("Administrador inicial: faltan catálogos (Área con dirección, Cargo o LugarTrabajo). Falta cargar los datos iniciales.");
            return null;
        }

        return new Trabajador
        {
            Rut = TrabajadorValidator.FormatearParaGuardar(rut),
            PrimerNombre = nombre,
            PrimerApellido = apellido,
            FechaNacimiento = new DateOnly(1990, 1, 1),
            Sexo = "Prefiere no informar",
            Correo = correo,
            DireccionCorporativaId = area.PadreId!.Value,
            AreaId = area.Id,
            CargoId = cargoId.Value,
            LugarTrabajoId = lugarId.Value,
            FechaIncorporacion = DateOnly.FromDateTime(DateTime.UtcNow),
            Activo = true
        };
    }
}
