# Configuración del backend

Los secretos **no van en `appsettings.json`** ni en ningún archivo del repositorio. Si falta alguno, la API
no arranca y muestra un mensaje que dice cuál falta y cómo configurarlo.

| Clave | Qué es | Secreto | Dónde se usa |
|---|---|---|---|
| `ConnectionStrings:Default` | Cadena de conexión a PostgreSQL | Sí | Siempre |
| `AuthDesarrollo:Clave` | Llave para firmar el token del login de desarrollo (mínimo 32 caracteres) | Sí | Solo en Development |
| `AzureAd:TenantId`, `AzureAd:ClientId`, `AzureAd:Audience` | Datos de la app en Microsoft Entra ID | No (son públicos) | Siempre; ya están en `appsettings.json` |
| `Cors:Origenes` | URL(s) del frontend que pueden llamar a la API desde el navegador | No | Siempre; en desarrollo ya viene `http://localhost:4200` |
| `AllowedHosts` | Dominio(s) por los que se llega a la API, separados por `;` | No | Obligatorio fuera de desarrollo (no se acepta `*`) |

## En tu equipo (desarrollo)

Se usan los *user-secrets* de .NET: se guardan en tu usuario de Windows
(`%APPDATA%\Microsoft\UserSecrets\63bd35e4-188e-47c8-9e93-ecbc385a89b6\secrets.json`), fuera del repositorio.
Se configuran una sola vez, desde `backend/src/MafTi.Api`:

```bash
dotnet user-secrets set "ConnectionStrings:Default" "Host=localhost;Port=5432;Database=maf_ti;Username=postgres;Password=TU_CONTRASEÑA"
dotnet user-secrets set "AuthDesarrollo:Clave" "una-clave-larga-de-al-menos-32-caracteres"
```

Para ver qué tienes configurado: `dotnet user-secrets list`.

Los user-secrets solo se cargan con `ASPNETCORE_ENVIRONMENT=Development`, que es lo que usan `dotnet run` y
`dotnet ef` en desarrollo.

## En el servidor (producción)

Se usan **variables de entorno**. En los nombres, los dos puntos (`:`) se reemplazan por doble guion bajo (`__`):

```
ASPNETCORE_ENVIRONMENT=Production
ConnectionStrings__Default=Host=...;Port=5432;Database=maf_ti;Username=...;Password=...
Cors__Origenes__0=https://<dominio del frontend>
AllowedHosts=<dominio de la API>
ASPNETCORE_HTTPS_PORT=443
```

Si hay más de un frontend permitido: `Cors__Origenes__1=...`, `Cors__Origenes__2=...`. Si la API se
publica bajo más de un nombre: `AllowedHosts=api.dominio.cl;otro.dominio.cl`.

### En contenedor (ECS detrás de CloudFront y ALB)

La imagen (Linux **ARM64**) se construye con el `Dockerfile` de la raíz y la publica
`.github/workflows/deploy-ecs.yml` como `:latest`, forzando un nuevo deployment. La task definition y sus
variables las administra Terraform (repo `Maf.Infra.Terraform.Gestionti`), no este repo.

- La API escucha en el puerto **8080** por HTTP. El HTTPS lo terminan CloudFront y el ALB.
- **No definir `ASPNETCORE_HTTPS_PORT`**: la API recibe las peticiones por HTTP desde el ALB y, con esa variable,
  las redirige a HTTPS una y otra vez (bucle de redirecciones).
- Base de datos: ECS inyecta `DB_HOST`, `DB_PORT`, `DB_NAME`, `DB_USERNAME` y `DB_PASSWORD` (los dos últimos desde
  Secrets Manager). La API arma la cadena con SSL obligatorio y un pool máximo de 20 conexiones
  (`Common/ConexionBaseDatos.cs`). Si existe `ConnectionStrings__Default`, tiene prioridad.
- Al arrancar, la API espera hasta 2 minutos a que la base responda (en QA, RDS se enciende por horario).
- `BaseDatos__AplicarMigraciones=true` hace que la API aplique las migraciones pendientes al arrancar. Es la
  forma de migrar en ECS, porque la base solo es alcanzable desde la VPC.
- `AllowedHosts` es el dominio que CloudFront entrega en el `Host` (ej. `gestionti-qa.mafti.cl`). Se aceptan
  comodines de subdominio (`*.mafti.cl`).
- Health check del ALB: `GET /health` (responde `200 {"estado":"ok"}`). No exige sesión y queda fuera del filtro
  de `AllowedHosts`, porque el ALB envía como `Host` la IP del contenedor.

Variables que debe definir Terraform en la task definition (además de las `DB_*`):

```
ASPNETCORE_ENVIRONMENT=Production
AllowedHosts=gestionti-qa.mafti.cl;api-gestionti-qa.mafti.cl
Cors__Origenes__0=https://gestionti-qa.mafti.cl
BaseDatos__AplicarMigraciones=true
ASPNETCORE_FORWARDEDHEADERS_ENABLED=true
DOTNET_gcServer=0
```

- `ASPNETCORE_FORWARDEDHEADERS_ENABLED=true` hace que la API confíe en `X-Forwarded-For`/`X-Forwarded-Proto` del
  ALB (por defecto solo confía en un proxy local). Es seguro porque el security group de la tarea solo admite
  tráfico del ALB.
- `DOTNET_gcServer=0` reduce la memoria que retiene .NET, para que el autoscaling por memoria no suba a 2 tareas sin carga.

### Base nueva: datos iniciales y primer administrador

1. **Roles, permisos y catálogos:** los carga la migración `DatosIniciales` (se aplica sola con
   `BaseDatos__AplicarMigraciones=true`). Debe crear el rol `Gestión General` con todos los permisos y al menos
   un catálogo activo de `Area` (con `PadreId` hacia su `DireccionCorporativa`), `Cargo` y `LugarTrabajo`.
2. **Primer administrador:** lo crea la API al arrancar (`Seguridad/AdministradorInicial.cs`). En ECS, las
   cuatro variables llegan desde el secreto `mafchile-gestionti-admin-inicial-qa` de Secrets Manager (claves
   `correo`, `rut`, `nombre`, `apellido`), porque son datos personales:

   ```
   BaseDatos__AdministradorInicial__Correo=nombre.apellido@mafchile.com
   BaseDatos__AdministradorInicial__Rut=12345678-9
   BaseDatos__AdministradorInicial__Nombre=Nombre
   BaseDatos__AdministradorInicial__Apellido=Apellido
   ```

   Solo actúa si no existe ningún usuario activo con rol `Gestión General`. Si el correo ya pertenece a un
   trabajador, usa ese trabajador. Si no, lo crea con datos laborales provisionales (primeros catálogos
   activos, fecha de nacimiento 1990-01-01), que se corrigen después en su ficha. Cuando ya existe el
   administrador, las variables no tienen efecto.

### HTTPS y servidor web

La API está pensada para ir **detrás de un servidor web** (IIS o nginx) que tiene el certificado y recibe el
HTTPS:

- El servidor web debe enviar las cabeceras `X-Forwarded-For` y `X-Forwarded-Proto` (IIS con el módulo de
  ASP.NET Core lo hace solo; en nginx: `proxy_set_header X-Forwarded-Proto $scheme;` y
  `proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;`).
- Por seguridad, la API solo confía en esas cabeceras si el servidor web está **en la misma máquina**. Si
  está en otra, hay que agregar su IP en `SeguridadHttp.cs` (`KnownProxies`).
- Una petición por HTTP se redirige a HTTPS (por eso `ASPNETCORE_HTTPS_PORT=443`), y las respuestas por HTTPS
  llevan HSTS: el navegador recuerda usar siempre HTTPS con ese dominio.

### Qué revisa la API al arrancar

Si falta algo, la API **no arranca** y dice qué falta: la cadena de conexión, los datos de Entra ID,
`Cors:Origenes` y, fuera de desarrollo, `AllowedHosts`. En producción, además, no existen el login de
desarrollo ni Swagger.

- `AuthDesarrollo__Clave` **no se configura** en el servidor: fuera de Development el login de desarrollo no
  existe.
- Usa en producción un usuario de PostgreSQL propio de la aplicación (no `postgres`) y una contraseña
  distinta a la de desarrollo.
- Agrega la URL real del frontend como redirect "Aplicación de página única (SPA)" en Entra ID.
- En el frontend, `apiUrl` de `src/environments/environment.ts` debe apuntar a `https://<dominio de la API>/api`.
- Los reportes en PDF usan una fuente del sistema: Arial en Windows; en Linux hay que instalar el paquete
  `fonts-dejavu` (o `fonts-liberation`). Sin fuente, la descarga en PDF responde con un error que lo indica.
- La librería de PDF (PDFsharp-MigraDoc) está fijada en 6.2.4, la última versión con licencia MIT: desde la
  6.5.0 es AGPL. No actualizarla sin revisar la licencia.
- El servidor debe tener la zona horaria `America/Santiago` disponible y los datos de idioma (ICU, en Linux el
  paquete `libicu`): el SLA se calcula en hora de Chile y el aviso de plazo usa los días en español.
- Los feriados del SLA están en la tabla `Feriados` (cargados 2026 y 2027). Antes de 2028 hay que agregar los del
  año siguiente con una migración.
